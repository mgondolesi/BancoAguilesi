package frd.utn.myapplication;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;

public class ConsultasAvtivity extends AppCompatActivity {


    private TextView tvBienvenida;
    private TextView tvRespuesta;
    private Button btnModificar;
    private Button btnSaldo;
    private Button btnMovimientos;

    String numeroCliente = getIntent().getStringExtra("cliente");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultas);


        btnModificar = (Button)findViewById(R.id.btnModificar);
        btnSaldo = (Button)findViewById(R.id.btnSaldo);
        btnMovimientos = (Button)findViewById(R.id.btnMovimientos);
        tvBienvenida = (TextView)findViewById(R.id.tvBienvenida);
        tvRespuesta = (TextView)findViewById(R.id.tvRespuesta);



        tvBienvenida.setText("Bienvenido Cliente N°:"+numeroCliente);

        btnModificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { new asynkTaskModificar().execute();
            }
        });
        btnSaldo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new asynkTaskSaldo().execute();
            }
        });
        btnMovimientos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { new asynkTaskMovimientos().execute();
            }
        });
    }

    private class asynkTaskModificar extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... strings) {
            try{
                Thread.sleep(1000);
            }catch(InterruptedException e){
                e.printStackTrace();
            }
            return strings[0];
        }

        @Override
        protected void onPostExecute(String result) {
            Intent intent = new Intent(ConsultasAvtivity.this,ModificarActivity.class);
            intent.putExtra("cliente",numeroCliente);
            startActivity(intent);
        }
    }

    private class asynkTaskSaldo extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... strings) {
            return RESTService.makeGetRequest(
                    "http://www.mocky.io/v2/5b2276372e00007e00e316cf");
        }
        @Override
        protected void onPostExecute(String result) {
            Intent intent = new Intent(ConsultasAvtivity.this,CuentasActivity.class);
            intent.putExtra("resultado",result);
            startActivity(intent);
        }
    }

    private class asynkTaskMovimientos extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... strings) {
            return RESTService.makeGetRequest(
                    "http://www.mocky.io/v2/5b2276372e00007e00e316cf");
        }
        @Override
        protected void onPostExecute(String result) {
            Intent intent = new Intent(ConsultasAvtivity.this,MovimientosActivity.class);
            intent.putExtra("resultado",result);
            startActivity(intent);
        }
    }
}
