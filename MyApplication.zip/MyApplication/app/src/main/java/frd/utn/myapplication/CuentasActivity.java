package frd.utn.myapplication;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import de.codecrafters.tableview.TableView;
import de.codecrafters.tableview.model.TableColumnPxWidthModel;
import de.codecrafters.tableview.toolkit.SimpleTableDataAdapter;
import de.codecrafters.tableview.toolkit.SimpleTableHeaderAdapter;

public class CuentasActivity extends AppCompatActivity {

    private Button btnSaldo;
    private EditText etCuenta;
    private TableView<String[]> tableViewCuentas;
    private TextView tvSaldo;

    String result = getIntent().getStringExtra("resultado");

    private static final String[] TABLE_HEADERS = {"Creado","Descripcion","Importe"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cuentas);

        btnSaldo = (Button) findViewById(R.id.btnSaldo);
        etCuenta = (EditText) findViewById(R.id.etCuenta);
        tvSaldo = (TextView) findViewById(R.id.tvSaldo);
        tableViewCuentas = (TableView) findViewById(R.id.tableViewCuentas);

        TableColumnPxWidthModel columnModel = new TableColumnPxWidthModel(4, 350);
        columnModel.setColumnWidth(0, 350);
        columnModel.setColumnWidth(1, 350);
        columnModel.setColumnWidth(2, 350);
        tableViewCuentas.setColumnModel(columnModel);

        JSONArray jsonRecibido = null;
        try {
            jsonRecibido = new JSONArray(result);
            ArrayStructure s = new ArrayStructure();

            for (int i = 0; i < jsonRecibido.length(); i++) {
                JSONObject jo = jsonRecibido.getJSONObject(i);
                s.add(i,0,jo.getString("creado").substring(0,10));
                s.add(i,1, jo.getString("tipo"));
                s.add(i,2, jo.getString("importe"));


                String[][] DATA_TO_SHOW = s.toArray();

                tableViewCuentas.setHeaderAdapter(new SimpleTableHeaderAdapter(this, TABLE_HEADERS));
                tableViewCuentas.setDataAdapter(new SimpleTableDataAdapter(this, DATA_TO_SHOW));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        btnSaldo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CuentasActivity.asynkTaskSaldo().execute();
            }
        });
    }
    private class asynkTaskSaldo extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... strings) {
            String numeroCuenta = etCuenta.getText().toString();
            return RESTService.makeGetRequest(
                    "http://www.mocky.io/v2/5b2253412e00002a00e3162f");
        }
        @Override
        protected void onPostExecute(String result) {

            tvSaldo.setVisibility(View.VISIBLE);
            tvSaldo.setText("Su Saldo es :"+result);
        }
    }
}


